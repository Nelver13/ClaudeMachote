#!/usr/bin/env python3
# ARCHIVO: notificar.py
# QUÉ HACE: Hook Notification — lee el mensaje de Claude Code via stdin y llama avisar.py
# CÓMO ENCAJA: settings.json lo llama automáticamente en eventos Notification
# PARA EDITAR: cambiar tipo de aviso (suave/normal/urgente) según preferencia
# DEPENDENCIAS: avisar.py en el mismo directorio

import sys
import json
import os
import subprocess

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
AVISAR     = os.path.join(SCRIPT_DIR, 'avisar.py')

def main():
    # Claude Code pasa el evento como JSON por stdin
    try:
        data    = json.load(sys.stdin)
        mensaje = (
            data.get('message') or
            data.get('title') or
            data.get('notification') or
            'Claude completó una tarea'
        )
    except Exception:
        mensaje = 'Claude completó una tarea'

    # Limitar largo del mensaje para WhatsApp / toast
    if len(mensaje) > 200:
        mensaje = mensaje[:197] + '...'

    msg_lower = mensaje.lower()
    if any(w in msg_lower for w in ('error', 'falló', 'failed', 'urgent', 'urgente', 'secreto', 'secret')):
        tipo = 'urgente'
    elif any(w in msg_lower for w in ('terminada', 'completada', 'listo', 'aprobado')):
        tipo = 'normal'
    else:
        tipo = 'suave'

    subprocess.run(
        ['python', AVISAR, mensaje, tipo],
        cwd=os.path.dirname(SCRIPT_DIR)   # corre desde raíz del proyecto
    )

if __name__ == '__main__':
    main()
