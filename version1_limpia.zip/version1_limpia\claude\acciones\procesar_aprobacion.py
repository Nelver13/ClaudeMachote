# procesar_aprobacion.py
# Se ejecuta después de aprobar una discusión para procesar acciones automáticas
# Detecta el tipo de discusión y ejecuta scripts correspondientes

import os
import sys
import subprocess
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
CLAUDE_DIR = SCRIPT_DIR.parent
DISCUSIONES_DIR = CLAUDE_DIR / 'discusiones'

def detectar_tipo_discusion(filepath):
    """
    Detecta el tipo de discusión basado en su contenido
    """
    content = filepath.read_text(encoding='utf-8')

    # Verificar si es definición de visión
    if 'definicion_vision' in filepath.name.lower() or 'definir-vision' in filepath.name.lower():
        return 'definicion_vision'

    # Verificar si es desarrollo de módulo
    if '## Solución detectada:' in content:
        return 'desarrollo_modulo'

    # Verificar si es mejora o refactorización
    if 'mejora' in filepath.name.lower() or 'refactor' in filepath.name.lower():
        return 'mejora'

    return 'general'

def procesar_aprobacion_discusion(discusion_filename):
    """
    Procesa una discusión recién aprobada y ejecuta acciones automáticas
    """
    # Buscar la discusión en todas las subcarpetas
    disc_filepath = None
    for tipo_dir in ['creaciones', 'creacion', 'soluciones', 'mejoras']:
        candidate = DISCUSIONES_DIR / tipo_dir / discusion_filename
        if candidate.exists():
            disc_filepath = candidate
            break

    if not disc_filepath:
        print(f'Error: Discusión no encontrada: {discusion_filename}')
        return False

    # Verificar que esté aprobada
    content = disc_filepath.read_text(encoding='utf-8')
    if 'Estado: Aprobado' not in content:
        print('Error: La discusión no está aprobada')
        return False

    # Detectar tipo de discusión
    tipo = detectar_tipo_discusion(disc_filepath)
    print(f'📋 Tipo de discusión detectado: {tipo}')

    # Ejecutar acciones según el tipo
    if tipo == 'definicion_vision':
        print('🎯 Procesando definición de visión...')
        # Generar VISION.md automáticamente
        result = subprocess.run([
            sys.executable,
            str(SCRIPT_DIR / 'generar_vision.py'),
            discusion_filename
        ], capture_output=True, text=True, cwd=SCRIPT_DIR)

        if result.returncode == 0:
            print('✅ VISION.md generada exitosamente')
            print(result.stdout)
        else:
            print('❌ Error generando VISION.md:')
            print(result.stderr)
            return False

    elif tipo == 'desarrollo_modulo':
        print('🔧 Procesando desarrollo de módulo...')
        # Crear plan automáticamente
        result = subprocess.run([
            sys.executable,
            str(SCRIPT_DIR / 'crear_plan.py'),
            discusion_filename
        ], capture_output=True, text=True, cwd=SCRIPT_DIR)

        if result.returncode == 0:
            print('✅ Plan creado exitosamente')
            print(result.stdout)
        else:
            print('❌ Error creando plan:')
            print(result.stderr)
            return False

    else:
        print('📝 Discusión general aprobada - esperando instrucciones del arquitecto')

    # Notificar al arquitecto
    subprocess.run([
        sys.executable,
        str(SCRIPT_DIR / 'avisar.py'),
        f"Discusión {tipo} procesada automáticamente",
        "normal"
    ], cwd=SCRIPT_DIR)

    return True

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print('Uso: python procesar_aprobacion.py <discusion_filename>')
        print('Ejemplo: python procesar_aprobacion.py disc_definir-vision-proyecto.md')
        sys.exit(1)

    discusion_filename = sys.argv[1]
    procesar_aprobacion_discusion(discusion_filename)