# ARCHIVO: crear_discusion.py
# QUÉ HACE: Crea discusión nueva con template y aviso automático
# CÓMO ENCAJA: Claude lo llama al iniciar nueva discusión
# PARA EDITAR: Modificar template path si cambia estructura
# DEPENDENCIAS: avisar.py, TEMPLATE_DISCUSION.md

import os
import sys
import shutil
from datetime import datetime
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
CLAUDE_DIR = SCRIPT_DIR.parent
DISCUSIONES_DIR = CLAUDE_DIR / 'discusiones'
VISION_PATH = CLAUDE_DIR.parent / 'VISION.md'

def leer_vision_proyecto():
    """
    Lee la VISION.md para entender las soluciones y módulos del proyecto.
    Retorna información estructurada sobre stacks tecnológicos.
    """
    if not VISION_PATH.exists():
        return None

    content = VISION_PATH.read_text(encoding='utf-8')

    # Extraer soluciones de la tabla
    soluciones = {}
    lineas = content.split('\n')
    in_tabla = False

    for linea in lineas:
        if '| ID | Solución | Plataforma | Stack | Estado |' in linea:
            in_tabla = True
            continue
        elif in_tabla and linea.startswith('| S') and '|' in linea:
            # Parsear línea de solución: | S1 | API Backend | Django + DRF | Python + PostgreSQL | En desarrollo |
            partes = [p.strip() for p in linea.split('|')[1:-1]]
            if len(partes) >= 4:
                id_sol = partes[0]
                nombre = partes[1]
                plataforma = partes[2]
                stack = partes[3]
                estado = partes[4] if len(partes) > 4 else 'Pendiente'

                soluciones[id_sol] = {
                    'nombre': nombre,
                    'plataforma': plataforma,
                    'stack': stack,
                    'estado': estado
                }
        elif in_tabla and not linea.startswith('|'):
            break

    # Extraer módulos y qué soluciones los usan
    modulos = {}
    in_modulos = False

    for linea in lineas:
        if '## Módulos y qué solución los usa' in linea:
            in_modulos = True
            continue
        elif in_modulos and linea.startswith('| Módulo |'):
            # Saltar header
            continue
        elif in_modulos and linea.startswith('| ') and '|' in linea:
            # Parsear línea de módulo
            partes = [p.strip() for p in linea.split('|')[1:-1]]
            if len(partes) >= 5:
                modulo = partes[0]
                soluciones_modulo = {}
                for i, sol_id in enumerate(['S1', 'S2', 'S3', 'S4']):
                    if i + 1 < len(partes):
                        status = partes[i + 1]
                        if status in ['✅', '🔄', '❌']:
                            soluciones_modulo[sol_id] = status
                modulos[modulo.lower()] = soluciones_modulo
        elif in_modulos and not linea.startswith('|'):
            break

    return {
        'soluciones': soluciones,
        'modulos': modulos
    }

def detectar_solucion_por_tema(tema, vision_data):
    """
    Detecta qué solución del proyecto se está trabajando basado en el tema
    y la información de VISION.md
    """
    if not vision_data:
        return None

    tema_lower = tema.lower()

    # Buscar en módulos primero
    for modulo, soluciones in vision_data['modulos'].items():
        if modulo in tema_lower:
            # Encontrar la solución más relevante para este módulo
            for sol_id, status in soluciones.items():
                if status in ['✅', '🔄'] and sol_id in vision_data['soluciones']:
                    return vision_data['soluciones'][sol_id]

    # Si no se encuentra por módulo, buscar por palabras clave en soluciones
    for sol_id, solucion in vision_data['soluciones'].items():
        nombre_lower = solucion['nombre'].lower()
        plataforma_lower = solucion['plataforma'].lower()

        if any(word in tema_lower for word in nombre_lower.split() + plataforma_lower.split()):
            return solucion

    return None

def detectar_modulo_y_plan(tema, tipo):
    """
    Detecta automáticamente el módulo apropiado y genera plan preliminar.
    Ahora considera la VISION.md para stacks tecnológicos por solución.
    Si no existe VISION.md, genera discusión para definirla.
    """
    tema_lower = tema.lower()

    # Si es tipo definición de visión, siempre generar plan especial
    if tipo == 'definicion_vision':
        return generar_plan_definicion_vision(tema)

    # Leer información del proyecto
    vision_data = leer_vision_proyecto()

    # Si no existe VISION.md, esta DEBE ser la primera discusión para definirla
    if not vision_data:
        print("⚠️  VISION.md no existe. Debes crear primero la visión del proyecto.")
        print("💡 Sugerencia: python crear_discusion.py 'definir-vision-proyecto' definicion_vision")
        return None

    # Si existe VISION.md, proceder con detección normal
    solucion_detectada = detectar_solucion_por_tema(tema, vision_data)

    if solucion_detectada:
        return generar_plan_por_solucion(tema, solucion_detectada, vision_data)

    # Fallback al sistema legacy si no se detecta solución específica
    return detectar_modulo_legacy(tema, tipo)

def generar_plan_por_solucion(tema, solucion, vision_data):
    """
    Genera un plan específico basado en la solución detectada de VISION.md
    """
    sol_id = None
    for sid, s in vision_data['soluciones'].items():
        if s == solucion:
            sol_id = sid
            break

    nombre_sol = solucion['nombre']
    plataforma = solucion['plataforma']
    stack = solucion['stack']
    estado = solucion['estado']

    # Planes específicos por tipo de solución
    if 'API Backend' in nombre_sol or 'Django' in plataforma:
        modulo = 'django-drf'
        enfoque = f'Backend-first para {nombre_sol} - Compatible con todas las plataformas cliente'
        plan = [
            f'1. **Modelos Django** - Estructura de datos para {tema}',
            f'2. **Serializers DRF** - API contracts para {plataforma}',
            f'3. **Vistas API** - Endpoints RESTful con JWT',
            f'4. **URLs y routing** - Rutas versionadas /api/v1/',
            f'5. **Tests** - Validación completa de API'
        ]
        complejidad = 'Media-Alta' if estado == 'En desarrollo' else 'Media'
        tiempo = '6-8 horas'
        archivos = ['models.py', 'serializers.py', 'views.py', 'urls.py', 'tests.py']

    elif 'Web Frontend' in nombre_sol or 'React' in plataforma:
        modulo = 'react-vite'
        enfoque = f'Frontend-first para {nombre_sol} - Conexión con API backend existente'
        plan = [
            f'1. **Componentes React** - UI para {tema}',
            f'2. **Servicios API** - Cliente para endpoints backend',
            f'3. **Páginas Vite** - Rutas y navegación',
            f'4. **Estado Global** - Gestión de datos y autenticación',
            f'5. **Integración** - Conexión completa con backend'
        ]
        complejidad = 'Media'
        tiempo = '4-6 horas'
        archivos = ['components/', 'services/', 'pages/', 'hooks/', 'App.jsx']

    elif 'Mobile' in nombre_sol or 'React Native' in plataforma:
        modulo = 'mobile'
        enfoque = f'Mobile-first para {nombre_sol} - Reutilizando API backend'
        plan = [
            f'1. **Componentes Mobile** - UI nativa para {tema}',
            f'2. **Navegación** - Flujo de pantallas con React Navigation',
            f'3. **API Integration** - Cliente para backend existente',
            f'4. **Estado Local** - AsyncStorage y Context API',
            f'5. **Build & Test** - Compilación y testing en device'
        ]
        complejidad = 'Alta'
        tiempo = '8-12 horas'
        archivos = ['components/', 'screens/', 'services/', 'navigation/', 'App.js']

    elif 'Desktop' in nombre_sol or 'WinForms' in plataforma:
        modulo = 'desktop'
        enfoque = f'Desktop application para {nombre_sol} - Integración con API backend'
        plan = [
            f'1. **Forms y Controles** - UI de Windows para {tema}',
            f'2. **Data Binding** - Conexión con API REST',
            f'3. **Business Logic** - Lógica específica de desktop',
            f'4. **Settings** - Configuración y persistencia',
            f'5. **Packaging** - Instalador y distribución'
        ]
        complejidad = 'Media'
        tiempo = '6-10 horas'
        archivos = ['Forms/', 'Controls/', 'Services/', 'Models/', 'Setup.iss']

    else:
        # Solución genérica
        modulo = 'django-drf'
        enfoque = f'Desarrollo para {nombre_sol} - {plataforma}'
        plan = [
            f'1. **Análisis** - Requisitos específicos de {tema}',
            f'2. **Implementación** - Desarrollo según {stack}',
            f'3. **Integración** - Conexión con otras soluciones',
            f'4. **Testing** - Validación funcional',
            f'5. **Documentación** - Guías de uso'
        ]
        complejidad = 'Media'
        tiempo = '4-8 horas'
        archivos = ['depende del stack']

    # Calcular riesgos basados en dependencias
    riesgos = []
    if sol_id and sol_id in vision_data['modulos'].get(tema.lower(), {}):
        # Verificar dependencias con otras soluciones
        for other_sol, status in vision_data['modulos'][tema.lower()].items():
            if other_sol != sol_id and status in ['✅', '🔄']:
                riesgos.append(f'Dependencia con {vision_data["soluciones"][other_sol]["nombre"]}')

    if not riesgos:
        riesgos = ['Alcance bien definido por VISION.md']

    return {
        'modulo': modulo,
        'enfoque': enfoque,
        'plan': plan,
        'complejidad': complejidad,
        'tiempo': tiempo,
        'archivos': archivos,
        'riesgos': riesgos,
        'solucion_detectada': solucion
    }

def generar_plan_definicion_vision(tema):
    """
    Genera un plan especial para definir la VISION.md del proyecto.
    Esta es la primera discusión que debe hacerse en cualquier proyecto.
    """
    return {
        'modulo': 'vision-proyecto',
        'enfoque': 'Definición estratégica del proyecto multi-solución',
        'plan': [
            '1. **Análisis del problema** - ¿Qué necesidad resuelve el proyecto?',
            '2. **Definición de soluciones** - ¿Qué plataformas necesitan? (Web, Mobile, Desktop, API)',
            '3. **Stack tecnológico** - Tecnologías específicas por solución',
            '4. **Módulos del sistema** - Funcionalidades y qué solución las implementa',
            '5. **Reglas y restricciones** - Limitaciones técnicas y de negocio',
            '6. **Roadmap de desarrollo** - Orden de implementación por fases'
        ],
        'complejidad': 'Alta',
        'tiempo': '2-4 horas',
        'archivos': ['VISION.md'],
        'riesgos': [
            'Alcance demasiado amplio o estrecho',
            'Tecnologías incompatibles entre soluciones',
            'Dependencias no consideradas',
            'Cambio de requisitos durante desarrollo'
        ],
        'tipo_especial': 'definicion_vision'
    }

def adaptar_template_para_vision(content, tema):
    """
    Adapta el template estándar para la definición de visión del proyecto.
    Agrega secciones específicas para definir soluciones, módulos y roadmap.
    """
    # Reemplazar la idea/problema con enfoque en visión
    content = content.replace('## Idea / problema\n- Que se quiere lograr o que falla.',
                             '''## Idea / problema
- ¿Qué necesidad resuelve este proyecto?
- ¿Para quién está dirigido?
- ¿Cuál es el problema principal que soluciona?

## Visión general del proyecto
- **Tipo de proyecto:** [Web/App/Sistema/Marketplace/etc.]
- **Alcance inicial:** [MVP/Producto completo/Solución enterprise]
- **Usuarios objetivo:** [Público general/Empresas/Usuarios específicos]
- **Valor principal:** [Qué hace único a este proyecto]''')

    # Reemplazar contexto técnico con definición de soluciones
    content = content.replace('''## Contexto técnico
- Stack afectado: [Django/DRF | React/Vite | PostgreSQL | JWT]
- Archivos impactados: [lista]
- Relación con VISION.md: [qué solución/plataforma afecta]''',
                             '''## Soluciones a desarrollar
Define qué plataformas/necesidades técnicas requiere el proyecto:

### Solución S1 - Backend API (Obligatoria)
- **Plataforma:** Django + DRF
- **Propósito:** API RESTful central para todas las plataformas
- **Stack:** Python + PostgreSQL + JWT
- **Estado inicial:** En desarrollo

### Solución S2 - Frontend Web (Opcional)
- **Plataforma:** React + Vite
- **Propósito:** Interfaz web para usuarios/administradores
- **Stack:** JavaScript/TypeScript + HTML/CSS
- **Estado inicial:** Pendiente

### Solución S3 - Mobile App (Opcional)
- **Plataforma:** React Native + Expo
- **Propósito:** Aplicación móvil nativa
- **Stack:** JavaScript + iOS/Android
- **Estado inicial:** Pendiente

### Solución S4 - Desktop App (Opcional)
- **Plataforma:** WinForms (C# o VB.NET)
- **Propósito:** Aplicación de escritorio para gestión
- **Stack:** .NET Framework + Windows
- **Estado inicial:** Pendiente''')

    # Modificar la sección de solución detectada
    content = content.replace('''## Solución detectada (VISION.md)
**Solución:** [S1/S2/S3/S4 - Nombre de la solución]
**Plataforma:** [Django + DRF | React + Vite | etc.]
**Stack tecnológico:** [Python + PostgreSQL | JavaScript/TypeScript | etc.]
**Estado actual:** [En desarrollo | Pendiente | etc.]
**Módulos relacionados:** [lista de módulos que usan esta solución]''',
                             '''## Módulos del sistema
Define las funcionalidades principales y qué solución las implementa:

| Módulo | S1 API | S2 Web | S3 Mobile | S4 Desktop | Endpoint Base |
|---|---|---|---|---|---|
| Autenticación | ✅ | ✅ | ✅ | ✅ | `/api/v1/auth/` |
| [Otro módulo] | [ ] | [ ] | [ ] | [ ] | `/api/v1/[modulo]/` |
| [Otro módulo] | [ ] | [ ] | [ ] | [ ] | `/api/v1/[modulo]/` |

**Leyenda:**
- ✅ Implementado y funcional
- 🔄 En desarrollo
- ❌ No aplica para esta solución''')

    # Modificar el plan de ejecución
    content = content.replace('''### Tareas propuestas:
- [ ] **Modelos Django** - Definir entidades y relaciones
- [ ] **Serializers DRF** - Validaciones y transformación de datos
- [ ] **Vistas API** - Endpoints RESTful con JWT
- [ ] **URLs y routing** - Configuración de rutas versionadas
- [ ] **Tests** - Cobertura básica de API''',
                             '''### Tareas para definir VISION.md:
- [ ] **Análisis del problema** - Definir necesidad y usuarios objetivo
- [ ] **Definición de soluciones** - Qué plataformas se necesitan realmente
- [ ] **Stack tecnológico** - Tecnologías específicas por solución
- [ ] **Módulos del sistema** - Funcionalidades y asignación a soluciones
- [ ] **Reglas y restricciones** - Limitaciones técnicas y de negocio
- [ ] **Roadmap de desarrollo** - Orden de implementación por fases''')

    # Modificar riesgos
    content = content.replace('''### Riesgos identificados:
- [Riesgo técnico específico del módulo django-drf]
- [Compatibilidad con VISION.md]''',
                             '''### Riesgos de la definición:
- Alcance demasiado amplio o estrecho para la primera fase
- Tecnologías incompatibles entre soluciones
- Dependencias no consideradas entre módulos
- Cambio de requisitos durante el desarrollo''')

    return content

def crear_discusion(tema, tipo):
    """
    Crea una nueva discusión con template y plan automático para ahorro de tokens.

    Args:
        tema: Nombre del tema (ej: 'crud-usuarios')
        tipo: 'creacion', 'solucion' o 'definicion_vision'
    """
    # Crear nombre de archivo
    fecha = datetime.now().strftime('%Y%m%d')
    filename = f'disc_{tema}.md'

    # Determinar carpeta según tipo
    if tipo == 'definicion_vision':
        carpeta_tipo = 'creaciones'  # Las definiciones de visión van en creaciones
    else:
        carpeta_tipo = tipo

    filepath = DISCUSIONES_DIR / carpeta_tipo / filename

    # Verificar que no exista
    if filepath.exists():
        print(f'Error: Discusión ya existe: {filepath}')
        return False

    # Detectar módulo y generar plan automático
    plan_auto = detectar_modulo_y_plan(tema, tipo)

    if plan_auto is None:
        return False

    # Copiar template
    template_path = DISCUSIONES_DIR / 'TEMPLATE_DISCUSION.md'
    if not template_path.exists():
        print(f'Error: Template no encontrado: {template_path}')
        return False

    # Leer template y reemplazar placeholders
    content = template_path.read_text(encoding='utf-8')
    content = content.replace('[tema]', tema)
    content = content.replace('YYYY-MM-DD', datetime.now().strftime('%Y-%m-%d'))
    content = content.replace('creacion | solucion', tipo)

    # Manejo especial para definición de visión
    if plan_auto.get('tipo_especial') == 'definicion_vision':
        content = adaptar_template_para_vision(content, tema)

    # Reemplazos específicos del plan automático
    content = content.replace('[Django/DRF | React/Vite | PostgreSQL | JWT]', f'{plan_auto["modulo"].upper()} + PostgreSQL + JWT')
    content = content.replace('[Backend-first para compatibilidad multi-plataforma]', plan_auto['enfoque'])
    content = content.replace('[Baja/Media/Alta]', plan_auto['complejidad'])
    content = content.replace('[X horas]', plan_auto['tiempo'])
    content = content.replace('[lista aproximada]', ', '.join(plan_auto['archivos']))

    # Reemplazos de solución detectada (si existe y no es definición de visión)
    if 'solucion_detectada' in plan_auto and plan_auto.get('tipo_especial') != 'definicion_vision':
        sol = plan_auto['solucion_detectada']
        # Encontrar ID de la solución
        sol_id = 'S?'
        vision_data = leer_vision_proyecto()
        if vision_data:
            for sid, s in vision_data['soluciones'].items():
                if s == sol:
                    sol_id = sid
                    break

        content = content.replace('[S1/S2/S3/S4 - Nombre de la solución]', f'{sol_id} - {sol["nombre"]}')
        content = content.replace('[Django + DRF | React + Vite | etc.]', sol['plataforma'])
        content = content.replace('[Python + PostgreSQL | JavaScript/TypeScript | etc.]', sol['stack'])
        content = content.replace('[En desarrollo | Pendiente | etc.]', sol['estado'])

        # Encontrar módulos relacionados
        modulos_rel = []
        if vision_data and tema.lower() in vision_data['modulos']:
            for sol_rel, status in vision_data['modulos'][tema.lower()].items():
                if status in ['✅', '🔄']:
                    modulos_rel.append(f'{sol_rel} ({status})')
        content = content.replace('[lista de módulos que usan esta solución]', ', '.join(modulos_rel) if modulos_rel else 'Ninguno específico')
    else:
        # Fallback para cuando no se detecta solución específica o es definición de visión
        content = content.replace('[S1/S2/S3/S4 - Nombre de la solución]', 'Por definir en VISION.md')
        content = content.replace('[Django + DRF | React + Vite | etc.]', 'Por determinar')
        content = content.replace('[Python + PostgreSQL | JavaScript/TypeScript | etc.]', 'Según definición del proyecto')
        content = content.replace('[En desarrollo | Pendiente | etc.]', 'Inicial')
        content = content.replace('[lista de módulos que usan esta solución]', 'Se definirán en VISION.md')

    # Reemplazar plan preliminar
    plan_text = '\n'.join(f'   {item}' for item in plan_auto['plan'])
    content = content.replace('''1. **Modelos Django** - Definir entidades y relaciones
2. **Serializers DRF** - Validaciones y transformación de datos
3. **Vistas API** - Endpoints RESTful con JWT
4. **URLs y routing** - Configuración de rutas versionadas
5. **Tests** - Cobertura básica de API''', plan_text)

    # Reemplazar riesgos específicos
    riesgos_text = '\n'.join(f'- {riesgo}' for riesgo in plan_auto['riesgos'])
    content = content.replace('[Riesgo técnico específico del módulo django-drf]\n- [Compatibilidad con VISION.md]', riesgos_text)

    # Crear directorio si no existe
    filepath.parent.mkdir(parents=True, exist_ok=True)

    # Escribir archivo
    filepath.write_text(content, encoding='utf-8')

    print(f'✅ Discusión creada con plan automático: {filepath}')
    print(f'📋 Módulo detectado: {plan_auto["modulo"]}')

    if plan_auto.get('tipo_especial') == 'definicion_vision':
        print(f'🎯 Tipo: DEFINICIÓN DE VISIÓN DEL PROYECTO')
        print(f'📝 Esta es la primera discusión - define VISION.md')
        print(f'🔧 Una vez aprobada, generará la VISION.md automáticamente')
    elif 'solucion_detectada' in plan_auto:
        sol = plan_auto['solucion_detectada']
        print(f'🎯 Solución VISION.md: {sol["nombre"]} ({sol["estado"]})')
        print(f'🛠️  Stack: {sol["stack"]}')

    print(f'🎯 Enfoque: {plan_auto["enfoque"]}')
    print(f'⏱️  Estimación: {plan_auto["tiempo"]} ({plan_auto["complejidad"]})')

    # Enviar aviso automático
    os.system(f'python "{SCRIPT_DIR}/avisar.py" "disc_{tema}.md listo — marca 1 (plan automático incluido)" suave')

    return True

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Uso: python crear_discusion.py <tema> [tipo]')
        print('Ejemplo: python crear_discusion.py crud-usuarios creacion')
        sys.exit(1)

    tema = sys.argv[1]
    tipo = sys.argv[2] if len(sys.argv) > 2 else 'creacion'

    if tipo not in ['creacion', 'solucion', 'definicion_vision']:
        print('Tipo debe ser: creacion, solucion o definicion_vision')
        sys.exit(1)

    crear_discusion(tema, tipo)