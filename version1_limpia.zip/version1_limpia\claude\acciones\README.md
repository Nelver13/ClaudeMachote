# claude/acciones/ — Scripts de modo ia v2.0

| Script | Cuándo corre | Quién lo llama | Avisos automáticos |
|---|---|---|---|
| `init_db.py` | Una vez al inicio del proyecto | Manual | ❌ |
| `crear_discusion.py <tema> [tipo]` | Al iniciar nueva discusión | Claude | ✅ `suave` |
| `procesar_aprobacion.py <disc_filename>` | Después de aprobar discusión | Manual | ✅ `normal` |
| `generar_vision.py <disc_filename>` | Al aprobar definición de visión | procesar_aprobacion.py | ❌ |
| `crear_plan.py <disc_filename>` | Al aprobar discusión desarrollo | procesar_aprobacion.py | ✅ `normal` |
| `actualizar_checklist.py <plan> <N>` | Al completar tarea | Claude | ✅ `suave` |
| `iniciar_dashboard.py` | Al abrir Claude Code | Hook UserPromptSubmit | ❌ |
| `motor_detect.py` | Al abrir Claude Code | iniciar_dashboard.py | ❌ |
| `iniciar_sesion.py` | Al abrir Claude Code | iniciar_dashboard.py | ❌ |
| `cerrar_sesion.py` | Al cerrar sesión | Manual | ❌ |
| `finalizar_etapa.py [nombre]` | Al cerrar etapa | Claude | ✅ `normal` |
| `actualizar_memoria.py` | Al cerrar etapa / manual | finalizar_etapa.py | ❌ |
| `avisar.py "msg" tipo` | Al terminar pasos/etapas | Claude | ❌ (es el aviso) |
| `notificar.py` | Eventos de notificación | Hook Notification | ❌ |
| `check_secrets.py` | Antes de cada Bash | Hook PreToolUse | ❌ |
| `log_escritura.py` | Después de cada Write | Hook PostToolUse | ❌ |
| `backup_n8n.py [N]` | Al cerrar etapa (si hay n8n) | Claude | ❌ |
| `backup_sql.py [N]` | Al cerrar etapa (si hay DB) | Claude | ❌ |

## Tipos de aviso
- `suave` — discusión actualizada, "marca 1"
- `normal` — etapa terminada, plan listo
- `urgente` — error, secreto detectado

## Canales soportados
- Windows (toast/popup) + sonido local
- Webhook (Discord/Slack compatibles con JSON)

## Diagnóstico de notificaciones
- Prueba completa: `python claude/acciones/avisar.py --test`
- Log de envíos y errores: `claude/logs/notificaciones.log`
- Canal recomendado: `Webhook` (Discord/Slack)
- Si no suena:
  - Colocar `aviso_suave.mp3`, `aviso_normal.mp3`, `aviso_urgente.mp3` en `claude/acciones/`
  - Si no hay mp3, usa fallback de sonido del sistema

## Memoria operativa
- Archivo central: `claude/memoria/MEMORIA.md`
- Se actualiza al cerrar etapa y resume:
  - estado actual (`estado.log`)
  - ultima discusion
  - ultimo plan

## Credenciales
En `credenciales.md` — mismo directorio. Tener la credencial = permiso de usarla.
---

## Flujo completo integrado v2.0 — Visión First

### 🚀 INICIO: Definición de Visión (OBLIGATORIA)

```
1. Arquitecto: "Definir visión del proyecto"
2. Claude: python crear_discusion.py definir-vision-proyecto definicion_vision
   → ✓ Detecta que NO existe VISION.md → fuerza definición
   → ✓ Discusión creada con template especial de visión
   → ✓ Aviso: "disc_definir-vision-proyecto.md listo — marca 1"

3. Arquitecto LEE y DEFINE:
   - Soluciones del proyecto (S1 API, S2 Web, S3 Mobile, S4 Desktop)
   - Módulos y qué solución los implementa
   - Restricciones técnicas y roadmap

4. Arquitecto: 0 (aprobar)
5. Claude: python procesar_aprobacion.py disc_definir-vision-proyecto.md
   → ✓ Detecta tipo "definicion_vision"
   → ✓ Ejecuta: python generar_vision.py disc_definir-vision-proyecto.md
   → ✓ Genera VISION.md automáticamente con soluciones y módulos
   → ✓ Aviso: "VISION.md generada — proyecto definido"
```

### 🔧 DESARROLLO: Módulos por Solución

```
6. Arquitecto: "Crear módulo de autenticación"
7. Claude: python crear_discusion.py autenticacion-usuarios desarrollo
   → ✓ Lee VISION.md → detecta solución S1 (API Backend)
   → ✓ Discusión creada con template adaptado para S1
   → ✓ Aviso: "disc_autenticacion-usuarios.md listo — marca 1"

8. Arquitecto LEE y MODIFICA el plan:
   - Agrega/quita tareas específicas para S1
   - Verifica que siga las reglas de VISION.md

9. Arquitecto: 0 (aprobar)
10. Claude: python procesar_aprobacion.py disc_autenticacion-usuarios.md
    → ✓ Detecta tipo "desarrollo_modulo"
    → ✓ Ejecuta: python crear_plan.py disc_autenticacion-usuarios.md
    → ✓ Extrae plan → checklist en plan_002.md
    → ✓ Aviso: "plan_002.md listo — empezando desarrollo S1"

11. Claude ejecuta tareas y ACTUALIZA checklist:
    → python actualizar_checklist.py plan_002.md 1
    → ✓ Aviso: "Tarea 1 completada — 1/8"
    → python actualizar_checklist.py plan_002.md 2
    → ✓ Aviso: "Tarea 2 completada — 2/8"

12. Claude: python finalizar_etapa.py "Autenticación S1"
    → ✓ Aviso: "Módulo autenticación terminado — listo para siguiente"
```

**Características del flujo visión-first:**
- 🎯 **Visión Obligatoria**: Todo proyecto inicia con VISION.md
- 🔍 **Detección Inteligente**: Cada módulo se desarrolla en su solución correcta
- 📋 **Templates Adaptados**: Discusiones se generan según la solución detectada
- 🔄 **Generación Automática**: VISION.md se crea desde la discusión aprobada
- ✅ **Control Arquitecto**: Modifica planes antes de aprobar, mantiene control total