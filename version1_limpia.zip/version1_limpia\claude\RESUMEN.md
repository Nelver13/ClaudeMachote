# RESUMEN.md — Estado del proyecto
> Actualizado automáticamente por finalizar_etapa.py

---

**Proyecto:** [Nombre del proyecto]
**Stack:** [Tecnologías principales]
**Última actividad:** [Fecha y descripción]
**Próximo paso:** [Qué hacer ahora]

---

## Historial reciente
- [Fecha] - [Actividad]
- [Fecha] - [Actividad]
- [Fecha] - [Actividad]

---

## Estado actual
- ✅ [Tarea completada]
- 🔄 [Tarea en progreso]
- ❌ [Tarea pendiente]