# ARCHIVO: crear_plan.py
# QUÉ HACE: Crea plan desde discusión aprobada con avisos automáticos
# CÓMO ENCAJA: Claude lo llama cuando arquitecto dice '0'
# PARA EDITAR: Modificar lógica de numeración de planes
# DEPENDENCIAS: avisar.py, TEMPLATE_PLAN.md

import os
import sys
import re
from datetime import datetime
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
CLAUDE_DIR = SCRIPT_DIR.parent
PLANES_DIR = CLAUDE_DIR / 'planes'
DISCUSIONES_DIR = CLAUDE_DIR / 'discusiones'
def extraer_plan_de_discusion(filepath):
    """Extrae el plan editable de la discusión para crear el checklist ejecutable."""
    content = filepath.read_text(encoding='utf-8')

    # Buscar la sección "Plan de ejecución" completa
    plan_section = ""
    in_plan_section = False
    for line in content.split('\n'):
        if line.startswith('## Plan de ejecución'):
            in_plan_section = True
            continue
        elif line.startswith('## ') and in_plan_section:
            break
        elif in_plan_section:
            plan_section += line + '\n'

    # Extraer tareas con checkboxes de toda la sección del plan
    tareas = []
    for line in plan_section.split('\n'):
        line = line.strip()
        if line.startswith('- [ ]'):
            # Extraer solo el texto de la tarea (sin el checkbox)
            tarea_texto = line[6:].strip()  # Remover '- [ ] ' (6 caracteres)
            tareas.append(f'- [ ] {tarea_texto}')

    return tareas

def extraer_info_discusion(filepath):
    """Extrae información básica de la discusión para el plan."""
    content = filepath.read_text(encoding='utf-8')

    # Extraer título
    title_match = re.search(r'^# (.+)$', content, re.MULTILINE)
    titulo = title_match.group(1) if title_match else 'Sin título'

    # Extraer tipo
    tipo_match = re.search(r'\*\*Tipo:\*\* (.+)', content)
    tipo = tipo_match.group(1) if tipo_match else 'desconocido'

    return {
        'titulo': titulo,
        'tipo': tipo,
        'filepath': filepath
    }

def crear_plan(discusion_filename):
    """
    Crea un plan desde una discusión aprobada.

    Args:
        discusion_filename: Nombre del archivo de discusión (ej: 'disc_crud-usuarios.md')
    """
    print(f"DEBUG: Buscando discusión {discusion_filename}")
    print(f"DEBUG: DISCUSIONES_DIR = {DISCUSIONES_DIR}")

    # Buscar la discusión en ambas carpetas
    disc_filepath = None
    for tipo_dir in ['creaciones', 'creacion', 'soluciones']:
        candidate = DISCUSIONES_DIR / tipo_dir / discusion_filename
        print(f"DEBUG: Checking {candidate} -> exists: {candidate.exists()}")
        if candidate.exists():
            disc_filepath = candidate
            break

    if not disc_filepath:
        print(f'Error: Discusión no encontrada: {discusion_filename}')
        return False

    # Verificar que esté aprobada
    content = disc_filepath.read_text(encoding='utf-8')
    if 'Estado: Aprobado' not in content:
        print('Error: La discusión no está aprobada (falta "Estado: Aprobado")')
        return False

    # Extraer info
    info = extraer_info_discusion(disc_filepath)

    # Extraer plan editable
    tareas = extraer_plan_de_discusion(disc_filepath)
    if not tareas:
        print('Error: No se encontraron tareas en el plan editable')
        return False

    # Generar número de plan
    planes_existentes = list(PLANES_DIR.glob('plan_*.md'))
    numero = len(planes_existentes) + 1
    plan_filename = f'plan_{numero:03d}.md'
    plan_filepath = PLANES_DIR / plan_filename

    # Copiar template
    template_path = PLANES_DIR / 'TEMPLATE_PLAN.md'
    if not template_path.exists():
        print(f'Error: Template no encontrado: {template_path}')
        return False

    # Leer template y reemplazar
    content = template_path.read_text(encoding='utf-8')
    content = content.replace('#XXX', f'#{numero:03d}')
    content = content.replace('[Nombre]', info['titulo'])
    content = content.replace('YYYY-MM-DD', datetime.now().strftime('%Y-%m-%d'))
    content = content.replace('disc_[tema].md', discusion_filename)

    # Reemplazar las tareas del template con las del plan editable
    # Buscar y reemplazar el bloque de tareas
    lines = content.split('\n')
    new_lines = []
    in_tareas_section = False
    skip_to_next_section = False

    for i, line in enumerate(lines):
        if '## Tareas' in line:
            in_tareas_section = True
            new_lines.append(line)
            new_lines.append('')
            # Agregar las tareas extraídas
            new_lines.extend(tareas)
            new_lines.append('')
            # Saltar las tareas originales del template
            skip_to_next_section = True
        elif skip_to_next_section and line.startswith('## '):
            # Fin de la sección de tareas original
            skip_to_next_section = False
            new_lines.append(line)
        elif not skip_to_next_section:
            new_lines.append(line)

    content = '\n'.join(new_lines)

    # Crear directorio si no existe
    plan_filepath.parent.mkdir(parents=True, exist_ok=True)

    # Escribir archivo
    plan_filepath.write_text(content, encoding='utf-8')

    print(f'✅ Plan ejecutable creado: {plan_filepath}')
    print(f'📋 Extraídas {len(tareas)} tareas del plan editable')

    # Enviar aviso automático
    os.system(f'python "{SCRIPT_DIR}/avisar.py" "plan_{numero:03d}.md listo — empezando ejecución" normal')

    return True

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print('Uso: python crear_plan.py <discusion_filename>')
        print('Ejemplo: python crear_plan.py disc_crud-usuarios.md')
        sys.exit(1)

    discusion_filename = sys.argv[1]
    crear_plan(discusion_filename)