# Credenciales — modo ia
> Este archivo viaja dentro de claude/acciones/ — nunca a git.
> Tener la credencial = tener permiso de usarla.

---

## Webhook (Discord)
- URL: https://discord.com/api/webhooks/1486588021963882531/s-f923hOARWTBp96NpjI8F2rrgc3M3rZKUtAYvfmWdj78XsEw1QAK3Epj0WIiF1vuXBo
- Estado: activa

---

## Notas
_(tokens temporales, instrucciones especiales, credenciales que expiran pronto)_
