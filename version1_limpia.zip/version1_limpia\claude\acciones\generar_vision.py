# generar_vision.py
# Genera VISION.md automáticamente desde una discusión aprobada de definición de visión
# Se ejecuta automáticamente cuando se aprueba una discusión de visión

import os
import sys
import re
from datetime import datetime
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
CLAUDE_DIR = SCRIPT_DIR.parent
DISCUSIONES_DIR = CLAUDE_DIR / 'discusiones'
VISION_PATH = CLAUDE_DIR.parent / 'VISION.md'

def extraer_info_vision(filepath):
    """
    Extrae la información de la discusión de visión para generar VISION.md
    """
    content = filepath.read_text(encoding='utf-8')

    info = {
        'titulo_proyecto': 'Nombre del Proyecto',
        'descripcion': '',
        'tipo_proyecto': '',
        'alcance': '',
        'usuarios': '',
        'valor': '',
        'soluciones': {},
        'modulos': {}
    }

    # Extraer información básica
    lines = content.split('\n')

    for i, line in enumerate(lines):
        line = line.strip()

        # Extraer título del proyecto del nombre del archivo
        if line.startswith('# disc_'):
            titulo_raw = line.replace('# disc_', '').replace('-', ' ').title()
            info['titulo_proyecto'] = titulo_raw

        # Extraer descripción del proyecto
        elif '## Idea / problema' in line:
            descripcion_lines = []
            for j in range(i+1, len(lines)):
                next_line = lines[j].strip()
                if next_line.startswith('##'):
                    break
                if next_line.startswith('- '):
                    descripcion_lines.append(next_line[2:])  # Remover el "- "
            info['descripcion'] = ' '.join(descripcion_lines)

        # Extraer visión general
        elif '## Visión general del proyecto' in line:
            # Leer las siguientes líneas hasta la siguiente sección
            for j in range(i+1, len(lines)):
                next_line = lines[j].strip()
                if next_line.startswith('##'):
                    break
                if next_line.startswith('- **Tipo de proyecto:**'):
                    info['tipo_proyecto'] = next_line.replace('- **Tipo de proyecto:**', '').strip()
                elif next_line.startswith('- **Alcance inicial:**'):
                    info['alcance'] = next_line.replace('- **Alcance inicial:**', '').strip()
                elif next_line.startswith('- **Usuarios objetivo:**'):
                    info['usuarios'] = next_line.replace('- **Usuarios objetivo:**', '').strip()
                elif next_line.startswith('- **Valor principal:**'):
                    info['valor'] = next_line.replace('- **Valor principal:**', '').strip()

        # Extraer módulos de la tabla
        elif '| Módulo |' in line:
            # Leer la tabla de módulos
            modulos_extraidos = {}
            soluciones_mencionadas = set()

            for j in range(i+2, len(lines)):  # Saltar header y separador
                table_line = lines[j].strip()
                if not table_line.startswith('| ') or table_line.startswith('| ---'):
                    continue
                if table_line.startswith('| [Otro módulo]') or not table_line.strip():
                    break

                # Parsear línea de módulo
                partes = [p.strip() for p in table_line.split('|')[1:-1]]
                if len(partes) >= 6:  # Módulo, S1, S2, S3, S4, Endpoint
                    modulo = partes[0].lower()
                    soluciones_modulo = {}

                    # Mapear las columnas S1, S2, S3, S4 (índices 1, 2, 3, 4)
                    for k, sol_id in enumerate(['S1', 'S2', 'S3', 'S4']):
                        if k + 1 < len(partes):
                            status = partes[k + 1]
                            if status in ['✅', '🔄', '❌']:
                                soluciones_modulo[sol_id] = status
                                if status in ['✅', '🔄']:
                                    soluciones_mencionadas.add(sol_id)

                    modulos_extraidos[modulo] = soluciones_modulo

            info['modulos'] = modulos_extraidos

            # Definir soluciones basadas en las que se usan en módulos
            soluciones_default = {
                'S1': {'nombre': 'API Backend', 'plataforma': 'Django + DRF', 'stack': 'Python + PostgreSQL', 'estado': 'En desarrollo'},
                'S2': {'nombre': 'Web Frontend', 'plataforma': 'React + Vite', 'stack': 'JavaScript/TypeScript', 'estado': 'Pendiente'},
                'S3': {'nombre': 'Mobile App', 'plataforma': 'React Native + Expo', 'stack': 'JavaScript', 'estado': 'Pendiente'},
                'S4': {'nombre': 'Desktop App', 'plataforma': 'WinForms', 'stack': 'C# o VB.NET', 'estado': 'Pendiente'}
            }

            # Incluir S1 siempre, y las demás si se mencionan en módulos
            for sol_id, sol_data in soluciones_default.items():
                if sol_id == 'S1' or sol_id in soluciones_mencionadas:
                    info['soluciones'][sol_id] = sol_data

    print(f"DEBUG: Modulos extraidos: {info['modulos']}")  # Debug
    return info

def generar_vision_md(info_vision):
    """
    Genera el contenido completo de VISION.md basado en la información extraída
    """
    fecha = datetime.now().strftime('%Y-%m-%d')

    # Determinar qué soluciones incluir (solo las que tienen sentido)
    soluciones_a_incluir = {}
    for sol_id, solucion in info_vision['soluciones'].items():
        # Incluir S1 siempre, las demás solo si se mencionan en módulos
        if sol_id == 'S1' or any(sol_id in mod for mod in info_vision['modulos'].values()):
            soluciones_a_incluir[sol_id] = solucion

    # Generar tabla de soluciones
    tabla_soluciones = """| ID | Solución | Plataforma | Stack | Estado |
|---|---|---|---|---|"""
    for sol_id in sorted(soluciones_a_incluir.keys()):
        sol = soluciones_a_incluir[sol_id]
        tabla_soluciones += f"\n| {sol_id} | {sol['nombre']} | {sol['plataforma']} | {sol['stack']} | {sol['estado']} |"

    # Generar tabla de módulos
    modulos_unicos = set()
    for modulo_data in info_vision['modulos'].values():
        for sol_id in modulo_data.keys():
            if sol_id in soluciones_a_incluir:
                modulos_unicos.add(sol_id)

    # Crear tabla de módulos
    tabla_modulos = """| Módulo | S1 API | S2 Web | S3 Mobile | S4 Desktop | Endpoint |
|---|---|---|---|---|---|"""
    for modulo, soluciones_modulo in info_vision['modulos'].items():
        s1_status = soluciones_modulo.get('S1', '❌') if 'S1' in soluciones_a_incluir else '❌'
        s2_status = soluciones_modulo.get('S2', '❌') if 'S2' in soluciones_a_incluir else '❌'
        s3_status = soluciones_modulo.get('S3', '❌') if 'S3' in soluciones_a_incluir else '❌'
        s4_status = soluciones_modulo.get('S4', '❌') if 'S4' in soluciones_a_incluir else '❌'

        endpoint = f"/api/v1/{modulo}/"
        tabla_modulos += f"\n| {modulo.title()} | {s1_status} | {s2_status} | {s3_status} | {s4_status} | {endpoint} |"

    # Generar restricciones basadas en las soluciones elegidas
    restricciones = []
    if 'S1' in soluciones_a_incluir:
        restricciones.extend([
            "**Framework Web:** Solo React + Vite (no Angular, Vue, Svelte)",
            "**Base de datos:** PostgreSQL obligatorio (no MySQL, SQLite para prod)",
            "**Autenticación:** JWT obligatorio (no sessions, OAuth2 directo)"
        ])
    if 'S2' in soluciones_a_incluir:
        restricciones.append("**Frontend:** Solo React + Vite con TypeScript")
    if 'S3' in soluciones_a_incluir:
        restricciones.append("**Mobile:** Solo React Native + Expo (no Flutter, native)")
    if 'S4' in soluciones_a_incluir:
        restricciones.append("**Desktop:** Solo WinForms (no WPF, Electron)")

    restricciones_texto = "\n- ".join(restricciones)

    # Generar roadmap básico
    roadmap = """1. **Fase 1:** API Backend completa (S1) — Base para todo
2. **Fase 2:** Web Frontend (S2) — Interfaz principal
3. **Fase 3:** Mobile App (S3) — Extensión móvil
4. **Fase 4:** Desktop App (S4) — Gestión avanzada"""

    # Generar contenido completo
    content = f"""# VISION.md — {info_vision.get('titulo_proyecto', 'Proyecto')}
**Generado:** {fecha}
**Última actualización:** {fecha}

## Qué hace el sistema
{info_vision.get('descripcion', '[Descripción del proyecto - qué problema resuelve]')}

## Soluciones previstas
{tabla_soluciones}

## Backend compartido
- **API Base:** `/api/v1/`
- **Autenticación:** JWT (SimpleJWT) — válido para todas las plataformas
- **Base de datos:** PostgreSQL
- **Servidor:** Django + Gunicorn (producción)

## Módulos y qué solución los usa
{tabla_modulos}

**Leyenda:**
- ✅ Implementado y funcional
- 🔄 En desarrollo
- ❌ No aplica

## Reglas derivadas de esta visión
- **API First:** Todo desarrollo parte de la API RESTful
- **JWT Universal:** Un token válido en web, mobile y desktop
- **Serializers Reutilizables:** Mismos serializers para todas las plataformas
- **Paginación Consistente:** Cursor-based para web y mobile, page-based para desktop
- **Validaciones Compartidas:** Lógica de negocio en backend, no duplicada en frontend

## Restricciones técnicas
{restricciones_texto}

## Roadmap de implementación
{roadmap}
"""

    return content

def generar_vision_desde_discusion(discusion_filename):
    """
    Genera VISION.md desde una discusión aprobada de definición de visión
    """
    # Buscar la discusión
    disc_filepath = None
    for tipo_dir in ['creaciones', 'creacion', 'soluciones']:
        candidate = DISCUSIONES_DIR / tipo_dir / discusion_filename
        if candidate.exists():
            disc_filepath = candidate
            break

    if not disc_filepath:
        print(f'Error: Discusion no encontrada: {discusion_filename}')
        return False

    # Verificar que esté aprobada
    content = disc_filepath.read_text(encoding='utf-8')
    if 'Estado: Aprobado' not in content:
        print('Error: La discusión no está aprobada')
        return False

    # Extraer información
    info_vision = extraer_info_vision(disc_filepath)

    # Generar VISION.md
    vision_content = generar_vision_md(info_vision)

    # Crear directorio si no existe
    VISION_PATH.parent.mkdir(parents=True, exist_ok=True)

    # Escribir archivo
    VISION_PATH.write_text(vision_content, encoding='utf-8')

    print(f'[OK] VISION.md generada automaticamente: {VISION_PATH}')
    print(f'[INFO] Soluciones definidas: {len(info_vision["soluciones"])}')
    print(f'[INFO] Modulos identificados: {len(info_vision["modulos"])}')

    return True

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print('Uso: python generar_vision.py <discusion_filename>')
        print('Ejemplo: python generar_vision.py disc_definir-vision-proyecto.md')
        sys.exit(1)

    discusion_filename = sys.argv[1]
    generar_vision_desde_discusion(discusion_filename)