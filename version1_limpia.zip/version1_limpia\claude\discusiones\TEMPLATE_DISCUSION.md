# disc_[tema]
**Tipo:** creacion | solucion
**Estado:** En discusión
**Fecha:** YYYY-MM-DD

## Idea / problema
- Que se quiere lograr o que falla.

## Contexto técnico
- Stack afectado: [Django/DRF | React/Vite | PostgreSQL | JWT]
- Archivos impactados: [lista]
- Relación con VISION.md: [qué solución/plataforma afecta]

## Solución detectada (VISION.md)
**Solución:** [S1/S2/S3/S4 - Nombre de la solución]
**Plataforma:** [Django + DRF | React + Vite | etc.]
**Stack tecnológico:** [Python + PostgreSQL | JavaScript/TypeScript | etc.]
**Estado actual:** [En desarrollo | Pendiente | etc.]
**Módulos relacionados:** [lista de módulos que usan esta solución]

## Plan de ejecución (editable - discutir aquí)
**Módulo detectado:** django-drf
**Enfoque recomendado:** [Backend-first para compatibilidad multi-plataforma]

### Tareas propuestas:
- [ ] **Modelos Django** - Definir entidades y relaciones
- [ ] **Serializers DRF** - Validaciones y transformación de datos
- [ ] **Vistas API** - Endpoints RESTful con JWT
- [ ] **URLs y routing** - Configuración de rutas versionadas
- [ ] **Tests** - Cobertura básica de API

### Estimación de tokens:
- **Complejidad:** [Baja/Media/Alta]
- **Tiempo estimado:** [X horas]
- **Archivos a crear/modificar:** [lista aproximada]

### Modificaciones del arquitecto:
_(Aquí el arquitecto puede agregar/quitar/modificar tareas del plan)_

### Riesgos identificados:
- [Riesgo técnico específico del módulo django-drf]
- [Compatibilidad con VISION.md]

## Checklist de aprobación
- [ ] Plan discutido y ajustado
- [ ] Estimación de tiempo realista
- [ ] Riesgos identificados y mitigados
- [ ] Compatible con VISION.md
- [ ] **APROBAR CON `0`** → genera checklist ejecutable

## Historial rápido
- YYYY-MM-DD HH:MM - Creada discusión
- YYYY-MM-DD HH:MM - Ajustes por R:/

## Resultado
- Cuando se aprueba: cambiar a `Estado: Aprobado`
- Referenciar plan: `plan_XXX.md`
